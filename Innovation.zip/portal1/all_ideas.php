<?php
session_start();
if(!isset($_SESSION['email'])){
    header("Location:student_login.php");
    exit(); 
}
?><?php
$connection=mysqli_connect('localhost','root','','portal');
if(!$connection){
  die("Database connection failed". mysqli_error($connection));
} 
$select_db = mysqli_select_db($connection,'portal');
if(!$select_db){
  die("Database selection failed" . mysqli_error($connection)); 
}
   ?>
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>All Ideas</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
  
  <style>
  body{
    background-image: url(img/bg1.jpg);
    background-attachment: fixed;

  }
  table{
    color: #29e8d8;
    font-size: 18px;
  }
</style>


</head>

<body>
  <?php include'student_header.php' ?>


<br><br><br><br><br><br>
<div class="container">
<?php
   $con=mysqli_connect("localhost","root","","portal");
   // Check connection
   if(mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }

   $result = mysqli_query($con,"SELECT * FROM student_ideas");

   echo "<table border='1' class=table table-hover id=table_header>
      <tr>

         <th>Title</th>
         <th>Description</th>
         <th>Catagory</th>
         <th>Technology</th>
         <th>Submitted By:</th>
         <th>Institute Id</th>
      </tr>";

   while($row = mysqli_fetch_array($result)) {
       echo "<tr>";
      echo "<td>" . $row['idea_title'] . "</td>";
      echo "<td>" . $row['idea_description'] . "</td>";
      echo "<td>" . $row['idea_catagory'] . "</td>";
      echo "<td>" . $row['idea_technology'] . "</td>";
      echo "<td>" . $row['student_name'] . "</td>";
      echo "<td>" . $row['institute_id'] . "</td>";

      echo "</tr>";
   }
   echo "</table>";

   mysqli_close($con);
?>
</div>
<center><button class="btn btn-primary" onclick="location.href = 'profile.php';">Go back</button></center>
  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>
  
  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 <?php include'footer.php' ?>
</body>

</html>
