<?php
$connection=mysqli_connect('localhost','root','','portal');
if(!$connection){
  die("Database connection failed". mysqli_error($connection));
} 
$select_db = mysqli_select_db($connection,'portal');
if(!$select_db){
  die("Database selection failed" . mysqli_error($connection)); 
}
   ?>
<?php
require_once('connect.php');
if(isset($_POST) & !empty($_POST)){
  $admin_name=$_POST['admin_name'];
  $title=$_POST['title'];
  $description=$_POST['description'];
  $catagory=$_POST['catagory'];
  $technology=$_POST['technology'];
  $dataTime = date("Y-m-d H:i:s");

   $sql = "INSERT INTO admin_ideas(admin_name,title,description,catagory,technology,dataTime) VALUES('$admin_name','$title','$description','$catagory','$technology','$dataTime')";

  $result= mysqli_query($connection , $sql);
  if($result){
    echo"Idea Submitted Successful";
  }else{
    echo"Sorry ! Idea not Sent. Try Again";
    echo mysqli_error($connection);
  }
  }
?>
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>Admin: Upload Idea</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

</head>

<body>
  <?php include'admin_header.php' ?>

<div class="container" style="margin-top: 9%;">
  <div class="row">
    <div class="col-sm-4"> </div>
<div class="col-md-4">
  
<h1 class="text-center text-success">Upload New Idea</h1>
<br/>

<div class="col-sm-12">

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      
<form method="post">

<div class="form-group">
    <input type="text" class="form-control" name="admin_name" placeholder="Enter your Name" required>
  </div>
  
  <div class="form-group">
        <input type="text" class="form-control" name="title"  placeholder="Enter Title of the Idea" required>
  </div>
  <div class="form-group">
        <input type="text" class="form-control" name="description"  placeholder="Enter Description of the Idea" required>
  </div>
  <div class="form-group">
        <input type="text" class="form-control" name="catagory"  placeholder="Enter catagory of the Idea" required>
  </div>
  <div class="form-group">
        <input type="text" class="form-control" name="technology"  placeholder="Enter Technologies of the Idea" required>
  </div>
  <input type="submit" class="btn btn-default btn-lg"  name="submit" value="Submit Idea"><input type="button" class="btn btn-default btn-lg" value="Go back">
 

</form>

    </div>

    <center></center>
   </div>
  </div>
</div>
</div>
</div>
<br>
  <?php include'footer.php' ?>

  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/stellar.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>

</html>
