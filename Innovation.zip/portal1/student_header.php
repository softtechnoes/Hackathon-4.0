<?php
session_start();
$connection=mysqli_connect('localhost','root','','portal');
if(!$connection){
  die("Database connection failed". mysqli_error($connection));
} 
$select_db = mysqli_select_db($connection,'portal');
if(!$select_db){
  die("Database selection failed" . mysqli_error($connection)); 
}
   ?>
  <div class="navbar navbar-fixed-top" role="navigation" data-0="line-height:100px; height:100px; background-color:rgba(0,0,0,0.3);" data-300="line-height:60px; height:60px; background-color:rgba(5, 42, 62, 1);">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      	  <span class="fa fa-bars color-white"></span>
        </button>
        <div class="navbar-logo">
          <a href="index.php"><img data-0="width:155px;" data-300=" width:120px;" src="img/logo/logo.png" alt=""></a>
        </div>
      </div>
      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav" data-0="margin-top:20px;" data-300="margin-top:5px;">
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="#section-about">About</a></li>
          <li><a href="#">FAQs</a></li>
          <li><a href="#">
            <?php
      $connection=mysqli_connect("localhost","root","");
      $db=mysqli_select_db($connection,"portal");
      $sql="SELECT institute_name FROM user_info where email='".$_SESSION['email']."'";
      $result = mysqli_query($connection, $sql);
      $count = mysqli_num_rows($result);
      echo "<td>" . $result->fetch_assoc()['institute_name'] . "</td>";
      ?>
          </a></li>
          <li><a href="#"><i class="fa fa-user"></i>
            <?php
      $connection=mysqli_connect("localhost","root","");
      $db=mysqli_select_db($connection,"portal");
      $sql="SELECT student_name FROM user_info where email='".$_SESSION['email']."'";
      $result = mysqli_query($connection, $sql);
      $count = mysqli_num_rows($result);
      echo "<td>" . $result->fetch_assoc()['student_name'] . "</td>";
      ?>
          </a></li>
          <li><a href="student_logout.php">Logout</a></li>
        </ul>
      </div>
      <!--/.navbar-collapse -->
    </div>
  </div>
