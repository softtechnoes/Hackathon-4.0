-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2018 at 05:57 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_ideas`
--

CREATE TABLE `student_ideas` (
  `id` int(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `institute_id` varchar(255) NOT NULL,
  `idea_title` varchar(255) NOT NULL,
  `idea_description` varchar(255) NOT NULL,
  `idea_catagory` varchar(255) NOT NULL,
  `idea_technology` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_ideas`
--

INSERT INTO `student_ideas` (`id`, `student_name`, `father_name`, `email`, `mobile`, `dob`, `institute_id`, `idea_title`, `idea_description`, `idea_catagory`, `idea_technology`) VALUES
(2, 'Rajndra', 'Jaypal singh', 'Rajendrasantaushi@gmail.com', '9756044280', '22/08/1996', '15164', 'Dashboard for all AICTE Initiatives & Schemes:', 'AICTE has come out with many initiatives and also running number of schemes for its stake holders. In order to display the status of all Initiatives and Schemes on single window a Dashboard is required.', 'Software', 'Android'),
(3, 'Vaisnavi Bhardwaj', 'Shiv Shankar sharma', 'Vaishnavimit432@gmail.co', '689851', '14/12/1998', '1654', 'Zila Vikas Manch (ZIVIMA) â€“ District Development Portal', 'A portal needs to be developed to facilitate district collector to upload the district specific problems, projects etc. The portal should be accessible to all the institutes so that the students can select the problems as their project work and submit sol', 'Software', 'Web Technology'),
(4, 'Raju', 'Jaypal singh', 'rsantaushi@gmail.com', '9756044280', '22/08/1996', '2565', 'Dashboard for all MHRD Initiatives & schemes', 'MHRD has come out with many initiatives and also running number of schemes for different type of stake holders. In order to display the status of all Initiatives and Schemes on single window a Dashboard is required.', 'Software', 'Application');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_ideas`
--
ALTER TABLE `student_ideas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_ideas`
--
ALTER TABLE `student_ideas`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
