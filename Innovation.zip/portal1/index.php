<?php
require_once('connect.php');
if(isset($_POST) & !empty($_POST)){
  $student_name=$_POST['student_name'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $city=$_POST['city'];
  $state=$_POST['state'];
  $message=$_POST['message'];
  $sql = "INSERT INTO messages(student_name,email,phone,city,state,message) VALUES('$student_name','$email','$phone','$city','$state','$message')";
  $result= mysqli_query($connection , $sql);
  if($result){
    echo"Message sent Successful. We will contact you soon.";
  }else{
    echo"Message sent failed. Try again";
    echo mysqli_error($connection);
  }
  }
?>
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>Welcome: : Homepage</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

</head>

<body>
  <?php include'home_header.php' ?>

  <section id="intro">
    <div class="intro-content">
      <h2>Welcome to Innovate Portal</h2>
      <h3>Take Ideas &amp; share Ideas !!</h3>
      <div>
        <button class="btn-get-started scrollto" onclick="location.href = 'student_login.php';">Get Started</button>
      </div>
    </div>
  </section>

  <!-- services -->
  <section id="section-services" class="section pad-bot30 bg-white">
    <div class="container">

      <div class="row mar-bot40">
        <div class="col-lg-4">
          <div class="hi-icon-wrap hi-icon-effect-5 hi-icon-effect-5a mar-top20">
            <div class="float-left mar-right20">
              <a href="http://innovationcouncilarchive.nic.in/index.php?option=com_content&view=article&id=39&Itemid=29" class="hi-icon hi-icon-screen">screen</a>
            </div>
          </div>
          <h3 class="text-bold">India Innvoation Portal</h3>
          <p>Innovation mission from Indian Government.</p>

          <div class="clear"></div>
        </div>

        <div class="col-lg-4">
          <div class="hi-icon-wrap hi-icon-effect-5 hi-icon-effect-5a mar-top20">
            <div class="float-left mar-right20">
              <a href="#" class="hi-icon hi-icon-location">location</a>
            </div>
          </div>
          <h3 class="text-bold">Information on India Innovation Portal</h3>
          <p>
The India Innovation Portal (IIP) is envisaged to network people, ideas and experiences and resources to galvanise the innovation community in the country.</p>

          <div class="clear"></div>
        </div>

        <div class="col-lg-4">
          <div class="hi-icon-wrap hi-icon-effect-5 hi-icon-effect-5a mar-top20">
            <div class="float-left mar-right20">
              <a href="#" class="hi-icon hi-icon-images">images</a>
            </div>
          </div>
          <h3 class="text-bold">Beautiful</h3>
          <p>Lorem ipsum dolor sit amet, elit persecuti efficiendi sit ad.</p>

          <div class="clear"></div>
        </div>

      </div>
      
  </section>

  <!-- spacer section:testimonial -->
  <section id="testimonials" class="section" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="align-center">
            <div class="flexslider testimonials-slider">
              <ul class="slides">
                <li>
                  <div class="testimonial clearfix">
                    <div class="mar-bot20">
                      <img alt="" src="img/testimonial/cm.jpg" class="img-circle" height="200px;">
                    </div>
                    <i class="fa fa-quote-left fa-5x"></i>
                    <h5>
												rajasthan is bigger  than germoney and has more people then france.being india's biggest state without much better much water is a huge challange.

											</h5>
                    <br/>
                    <span class="author">&mdash; Smt. Vasundhara Raje (CM Rajasthan)  </span>
                  </div>
                </li>

                <li>
                  <div class="testimonial clearfix">
                    <div class="mar-bot20">
                      <img alt="" src="img/testimonial/pm.jpg" class="img-circle" height="200px;">
                    </div>
                    <i class="fa fa-quote-left fa-5x"></i>
                    <h5>
												ones we decide wehave to do something, we can go miles ahead.
												</h5>
                    <br/>
                    <span class="author">&mdash; PM Narendra Modi</span>
                  </div>
                </li>
                <li>
                  <div class="testimonial clearfix">
                    <div class="mar-bot20">
                      <img alt="" src="img/testimonial/apjabdulkalam.jpg" class="img-circle" height="200px;">
                    </div>
                    <i class="fa fa-quote-left fa-5x"></i>
                    <h5>
											In a democracy, the well-being, individuality and happiness of every citizen is important for the overall prosperity, peace and happiness of the nation.
											</h5>
                    <br/>
                    <span class="author">&mdash; Dr. A.P.J. Abdul Kalam</span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

  

  <!-- spacer section:stats -->
  <section id="parallax1" class="section" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row appear stats">
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-commenting-o fa-5x"></i>
            </div>
            <strong id="counter-coffee" class="number">100</strong><br>
            <span class="text">Total Given Idea</span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-cogs fa-5x"></i>
            </div>
            <strong id="counter-music" class="number">345</strong><br>
            <span class="text">Solved Ideas</span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-envelope-o fa-5x"></i>
            </div>
            <strong id="counter-clock" class="number">1235</strong><br>
            <span class="text">Submitted Ideas</span>
          </div>
        </div>
        <div class="col-md-3">
          <div class="align-center color-white txt-shadow">
            <div class="icon">
              <i class="fa fa-signal fa-5x"></i>
            </div>
            <strong id="counter-heart" class="number">478</strong><br>
            <span class="text">Register Colleges</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- section works -->
  <section id="section-works" class="section appear clearfix">
    <div class="container">

      <div class="row mar-bot40">
        <div class="col-md-offset-3 col-md-6">
          <div class="section-header">
            <h2 class="section-heading animated" data-animation="bounceInUp">Themes</h2>
            <p>There are total 12 themes on which Rajasthan Governement running different different projects. All themes are differ from another themes, some themes are VR(Virtual Reality), BlackChain etc</p>
          </div>
        </div>
      </div>

      <div class="row">
        <nav id="filter" class="col-md-12 text-center">
          <ul>
            <li><a href="#" class="current btn btn-small" data-filter="*">All</a></li>
            <li><a href="#" class="btn btn-small" data-filter=".webdesign">VR</a></li>
            <li><a href="#" class="btn btn-small" data-filter=".photography">AI</a></li>
            <li><a href="#" class="btn btn-small" data-filter=".print">Data Warehouse</a></li>
          </ul>
        </nav>
        <div class="col-md-12">
          <div class="row">
            <div class="portfolio-items isotopeWrapper clearfix" id="3">

              <article class="col-md-4 isotopeItem webdesign">
                <div class="portfolio-item">
                  <img src="img/portfolio/ai.jpeg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Artificial Intelligence</a></h5>

                      <a href="img/portfolio/ai.jpeg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>

              <article class="col-md-4 isotopeItem photography">
                <div class="portfolio-item">
                  <img src="img/portfolio/data_mobility.jpeg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Data Mobility</a></h5>
                      <a href="img/portfolio/data_mobility.jpeg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>


              <article class="col-md-4 isotopeItem photography">
                <div class="portfolio-item">
                  <img src="img/portfolio/datawarehouse.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Data Warehouse</a></h5>
                      <a href="img/portfolio/datawarehouse.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>

              <article class="col-md-4 isotopeItem print">
                <div class="portfolio-item">
                  <img src="img/portfolio/img4.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Machine Learning</a></h5>
                      <a href="img/portfolio/img4.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>

              <article class="col-md-4 isotopeItem photography">
                <div class="portfolio-item">
                  <img src="img/portfolio/img5.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Internet Of Things</a></h5>
                      <a href="img/portfolio/img5.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>

              <article class="col-md-4 isotopeItem webdesign">
                <div class="portfolio-item">
                  <img src="img/portfolio/img6.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Virtual Reality</a></h5>
                      <a href="img/portfolio/img6.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>

              <article class="col-md-4 isotopeItem print">
                <div class="portfolio-item">
                  <img src="img/portfolio/img7.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Bhamashah Yojna</a></h5>
                      <a href="img/portfolio/img7.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>

              <article class="col-md-4 isotopeItem photography">
                <div class="portfolio-item">
                  <img src="img/portfolio/img8.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">E-Mitra</a></h5>
                      <a href="img/portfolio/img8.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>

              <article class="col-md-4 isotopeItem print">
                <div class="portfolio-item">
                  <img src="img/portfolio/img9.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Block Chain</a></h5>
                      <a href="img/portfolio/img9.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>
              <article class="col-md-4 isotopeItem print">
                <div class="portfolio-item">
                  <img src="img/portfolio/img9.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Big Data</a></h5>
                      <a href="img/portfolio/img9.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>
              <article class="col-md-4 isotopeItem print">
                <div class="portfolio-item">
                  <img src="img/portfolio/img9.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Bio Informatics</a></h5>
                      <a href="img/portfolio/img9.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>
              <article class="col-md-4 isotopeItem print">
                <div class="portfolio-item">
                  <img src="img/portfolio/img9.jpg" alt="">
                  <div class="portfolio-desc align-center">
                    <div class="folio-info">
                      <h5><a href="#">Tourism</a></h5>
                      <a href="img/portfolio/img9.jpg" class="fancybox"><i class="fa fa-plus fa-2x"></i></a>
                    </div>
                  </div>
                </div>
              </article>
            </div>

          </div>


        </div>
      </div>

    </div>
  </section>
  <section id="clients" class="section clearfix bg-white">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-sm-2 align-center">
              <img alt="logo" src="img/clients/logo1.png">
            </div>

            <div class="col-sm-2 align-center">
              <img alt="logo" src="img/clients/logo2.png">
            </div>

            <div class="col-sm-2 align-center">
              <img alt="logo" src="img/clients/logo3.png">
            </div>

            <div class="col-sm-2 align-center">
              <img alt="logo" src="img/clients/logo4.png">
            </div>

            <div class="col-sm-2 align-center">
              <img alt="logo" src="img/clients/logo5.png">
            </div>
            <div class="col-sm-2 align-center">
              <img alt="logo" src="img/clients/logo6.png">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- map -->
  <section id="section-map" class="clearfix">
    <div id="google-map" data-latitude="26.8851417" data-longitude="75.7868034"></div>
  </section>

  
 <br><br><br><br><br><br>
 <div class="container" id="contact-us">
        <div id="wrapper">
            <div id="page-wrapper-public">
    <div class="row">
        <div id="ContentPlaceHolder1_pnlDashboard" class="panel panel-primary">
  
            <div class="panel-heading">
                <h3 class="panel-title"><font color="#ffffff"><center>Contact Us</center></font></h3>
            </div>
           <center>
            <form method="post" ><br>
                    <input type="text" name="student_name" placeholder="Enter Name" id="contact" required="yes"><br><br>
                    <input type="text" name="email" placeholder="Enter Email"  id="contact" required="yes"><br><br>
                    <input type="text" name="phone" placeholder="Phone"  id="contact" required="yes"><br><br>
                    <input type="text" name="city" placeholder="City"  id="contact" required="yes"><br><br>
                    <input type="text" name="state" placeholder="State"  id="contact" required="yes"><br><br>
                    <textarea id="contact1" name="message" required="yes" placeholder="Enter Your Message here......."></textarea><br><br>
                    <input type="submit" class="btn btn-primary" style="background-color: blue;" name="submit" value="Send Message">
                    </div>
</form>
</center>
                    
                </div>
            </div>
        
</div>
    </div>

            </div>
        </div>
 </div><br>
  <?php include'footer.php' ?>
 

  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/jquery.nicescroll.min.js"></script>
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/stellar.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>

</html>
