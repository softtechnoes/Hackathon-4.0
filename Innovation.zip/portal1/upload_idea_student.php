<?php
$connection=mysqli_connect('localhost','root','','portal');
if(!$connection){
  die("Database connection failed". mysqli_error($connection));
} 
$select_db = mysqli_select_db($connection,'portal');
if(!$select_db){
  die("Database selection failed" . mysqli_error($connection)); 
}
   ?>
<?php
require_once('connect.php');
if(isset($_POST) & !empty($_POST)){
  $student_name=$_POST['student_name'];
  $father_name=$_POST['father_name'];
  $email=$_POST['email'];
  $mobile=$_POST['mobile'];
  $dob=$_POST['dob'];
  $institute_id=$_POST['institute_id'];
  $idea_title=$_POST['idea_title'];
  $idea_description=$_POST['idea_description'];
  $idea_catagory=$_POST['idea_catagory'];
  $idea_technology=$_POST['idea_technology'];

   $sql = "INSERT INTO student_ideas(student_name,father_name,email,mobile,dob,institute_id,idea_title,idea_description,idea_catagory,idea_technology) VALUES('$student_name','$father_name','$email','$mobile','$dob','$institute_id','$idea_title','$idea_description','$idea_catagory','$idea_technology')";

  $result= mysqli_query($connection , $sql);
  if($result){
    echo"Idea Submitted Successful";
  }else{
    echo"Sorry ! Idea not Sent. Try Again";
    echo mysqli_error($connection);
  }
  }
?>
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>Upload Idea</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

</head>

<body>
  <?php include'student_header.php' ?>

<div class="container" style="margin-top: 9%;">
  <div class="row">
    <div class="col-sm-4"> </div>
<div class="col-md-4">
  
<h1 class="text-center text-success">Upload Your Idea</h1>
<br/>

<div class="col-sm-12">

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      
<form method="post">

<div class="form-group">
    <input type="text" class="form-control" name="student_name" placeholder="Enter your Name" required>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="father_name" placeholder="Enter your Father's Name" required>
  </div>
  
 

  <div class="form-group">
    <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email" required>
  </div>

  <div class="form-group">
    <input type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="dob" placeholder="Enter Date Of Birth" required><font color="red">*</font> <font color="blue"> Date should be in DD/MM/YYYY</font>
  </div>
  
  <div class="form-group">
        <input type="text" class="form-control" name="institute_id"  placeholder="institution Id" required>
  </div>
  <div class="form-group">
        <input type="text" class="form-control" name="idea_title"  placeholder="Enter Title of the Idea" required>
  </div>
  <div class="form-group">
        <input type="text" class="form-control" name="idea_description"  placeholder="Enter Description of the Idea" required>
  </div>
  <div class="form-group">
        <input type="text" class="form-control" name="idea_catagory"  placeholder="Enter catagory of the Idea" required>
  </div>
  <div class="form-group">
        <input type="text" class="form-control" name="idea_technology"  placeholder="Enter Technologies of the Idea" required>
  </div>
  <input type="submit" class="btn btn-default btn-lg"  name="submit" value="Submit Idea">                   <input type="button" class="btn btn-default btn-lg" value="Go back" onclick="location.href = 'profile.php';">
 

</form>

    </div>

    <center></center>
   </div>
  </div>
</div>
</div>
</div>
<br>
  <?php include'footer.php' ?>

  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/stellar.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>

</html>
