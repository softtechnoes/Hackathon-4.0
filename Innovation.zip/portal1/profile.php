<?php
session_start();
if(!isset($_SESSION['email'])){
    header("Location:student_login.php");
    exit(); 
}
?>
<?php
$connection=mysqli_connect('localhost','root','','portal');
if(!$connection){
  die("Database connection failed". mysqli_error($connection));
} 
$select_db = mysqli_select_db($connection,'portal');
if(!$select_db){
  die("Database selection failed" . mysqli_error($connection)); 
}
   ?>
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>Welcome student</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
  
  <style>
  body{
    background-image: url(img/bg.jpg);
    background-attachment: fixed;
  }
</style>


</head>

<body>
  <?php include'student_header.php' ?>


 <br><br><br><br><br><br>
 <div class="container">
        <div id="wrapper">
            <div id="page-wrapper-public">
    <div class="row">
        <div id="ContentPlaceHolder1_pnlDashboard" class="panel panel-primary">
  
            <div class="panel-heading">
                <h3 class="panel-title"><font color="#ffffff"><center>Student Options</center></font></h3>
            </div>
           
            <div class="panel-body">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12">
                            
                            </div>
                        </div>
                    <div class="row">
                        <div class="col-md-4">
                            <center>
                            <div class="row">
                                <i class="fa fa-cloud-upload" style="font-size:90px;color:#00aaff;"></i>
                            </div>
                            <div class="row">
                                <a href="upload_idea_student.php" class="btn btn-primary" style="width:200px">Upload Your Idea</a>
                            </div>
                            </center>
                        </div>
                        <div class="col-md-4">
                            <center>
                            <div class="row">
                                <i class="fa fa-eye" style="font-size:90px;color:#00aaff;"></i>
                            </div>
                            <div class="row">
                                <a href="all_ideas.php" class="btn btn-primary" style="width:200px">View All Ideas</a>
                            </div>
                            </center>
                        </div>

                        
                        <div class="col-md-4">
                            <center>
                            <div class="row">
                                <i class="fa fa-folder-open" style="font-size:90px;color:#00aaff;"></i>
                            </div>
                            <div class="row">
                                <a href="admin_ideas.php"  class="btn btn-primary" style="width:200px">View Admin Ideas</a>
                            </div>

                            </center>
                        </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<center> <button class="btn btn-primary">Go</button></center>
                    </div>

                    
                </div>
            </div>
        
</div>
    </div>

            </div>
        </div>
 </div>

  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>
  
  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 <?php include'footer.php' ?>
</body>

</html>
