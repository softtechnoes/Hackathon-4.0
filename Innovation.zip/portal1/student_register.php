<?php
require_once('connect.php');
if(isset($_POST) & !empty($_POST)){
  $student_name=$_POST['student_name'];
 $father_name=$_POST['father_name'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $mobile=$_POST['mobile'];
 $gender=$_POST['gender'];
 $dob=$_POST['dob'];
 $institute_id=$_POST['institute_id'];
 $institute_name=$_POST['institute_name'];
 $institute_district=$_POST['institute_district'];
 $institute_city=$_POST['institute_city'];
 $institute_state=$_POST['institute_state'];
  $sql = "INSERT INTO user_info(student_name,father_name,email,password,mobile,gender,dob,institute_id,institute_name,institute_district,institute_city,institute_state) VALUES('$student_name','$father_name','$email','$password','$mobile','$gender','$dob','$institute_id','$institute_name','$institute_district','$institute_city','$institute_state')";
  $result= mysqli_query($connection , $sql);
  if($result){
    echo"Resgistration Successful";
  }else{
    echo"Sorry Registration not successful";
    echo mysqli_error($connection);
  }
  }
?>
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>Register Here</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

</head>

<body>
  <?php include'home_header.php' ?>

<div class="container" style="margin-top: 9%;">
  <div class="row">
    <div class="col-sm-4"> </div>
<div class="col-md-4">
  
<h1 class="text-center text-success"> Register page</h1>
<br/>

<div class="col-sm-12">

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      
<form action="#" method="post">

<div class="form-group">
    <input type="text" class="form-control" name="student_name" placeholder="Enter your Name" required>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="father_name" placeholder="Enter your Father's Name" required>
  </div>
  
 

  <div class="form-group">
    <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email" required>
  </div>

  <div class="form-group">
    <input type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required>
  </div>

  <select name="gender" class="form-control">
    <option   >Select Gender</option>
    <option value="male">Male</option>
    <option value="female">Female</option>
  </select>
  <br>
  <div class="form-group">
    <input type="text" class="form-control" name="dob" placeholder="Enter Date Of Birth" required><font color="red">*</font> <font color="blue"> Date should be in DD/MM/YYYY</font>
  </div>
  
  <div class="form-group">
        <input type="text" class="form-control" name="institute_id"  placeholder="institution Id" required>
  </div>

  <div class="form-group">
    
    <input type="password" class="form-control" name="password" placeholder="Create new Password" required>
  </div>

  <div class="form-group">
    
    <input type="password" class="form-control"  placeholder="Conform password" required>
  </div>
  <div class="form-group">
    
    <input type="text" class="form-control" name="institute_name"  placeholder="Enter Name of Institute" required>
  </div>
   
   <div class="form-group">
    
    <input type="text" class="form-control" name="institute_district"  placeholder="Enter your district" required>
  </div>

   <div class="form-group">
    
    <input type="text" class="form-control" name="institute_city"  placeholder="Enter your city" required>
  </div>

 <div class="form-group">
    <select class="form-control" name="institute_state" required>
      <option>Select Your State</option>
  <option value="Andaman and Nicobar ">Andaman and Nicobar </option>
  <option value="Andhra Pradesh">Andhra Pradesh</option>
  <option value="Assam">Assam</option>
  <option value="Bihar">Bihar</option>
  <option value="Chandigarh">Chandigarh</option>
  <option value="Chhattisgarh">Chhattisgarh</option>
  <option value="Dadra and Nagar">Dadra and Nagar </option>
  <option value="Daman and Diu">Daman and Diu</option>
  <option value="Delhi">Delhi</option>
  <option value="Goa">Goa</option>
  <option value="Gujraat">Gujraat</option>
  <option value="Hariyaana">Haryana</option>
  <option value="Himachal Pradesh">Himachal Pradesh</option>
  <option value="Jammu and Kashmir">Jammu and Kashmir</option>
  <option value="Jharkhand">Jharkhand</option>
  <option value="Karnataka">Karnataka</option>
  <option value="Kerala">Kerala</option>
  <option value="Lakshadweep ">Lakshadweep</option>
  <option value="Madhya Pradesh">Madhya Pradesh</option>
  <option value="Maharashtra">Maharashtra</option>
  <option value="Manipur">Manipur</option>
  <option value="Meghalaya">Meghalaya</option>
  <option value="Mizoram">Mizoram</option>
  <option value="Nagaland">Nagaland</option>
  <option value="Odisha">Odisha</option>
  <option value="Puducherry ">Puducherry </option>
  <option value="Punjab">Punjab</option>
  <option value="Rajasthan">Rajasthan</option>
  <option value="Sikkim">Sikkim</option>
  <option value="TAMIL NADU">TAMIL NADU</option>
   <option value="Telangana">Telangana</option>
    <option value="Tripura">Tripura</option>
    <option value ="Uttar Pradesh">Uttar Pradesh</option>
    <option value ="Uttarakhand">Uttarakhand</option>
    <option value ="West Bengal">West Bengal</option>
  <option value="state">state</option>
</select>
  </div>
  <input type="submit" class="btn btn-default btn-lg name="submit" value="Register">
 

</form>
<br/>
<button class="pull-right btn btn-block btn-danger" onclick="location.href = 'student_login.php';">Already Register ? </button>



    </div>

    <div id="menu1" class="tab-pane fade">

<form action="#">

  <div class="form-group">
    <label for="UserName">UserName</label>
    <input type="text" class="form-control" id="email">
  </div>
  
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email">
  </div>

  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd">
  </div>

  <div class="form-group">
    <label for="pwd">Confirm Password:</label>
    <input type="password" class="form-control" id="pwd">
  </div>



</form>
<br/>
<a href="#" class="pull-right btn btn-block btn-success" > Already Register ?   </a>
    </div>
   </div>
  </div>
</div>
</div>
</div>
<br>
  <?php include'footer.php' ?>

  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/stellar.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>

</html>
