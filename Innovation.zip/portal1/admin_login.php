<?php
session_start();
require_once('connect.php');
if(isset($_POST) & !empty($_POST)){
  $username=mysqli_real_escape_string($connection, $_POST['username']);
  $password=$_POST['password'];

  $sql="SELECT *FROM `admin_login` WHERE username='$username' AND password='$password'";
  $result = mysqli_query($connection, $sql);
  $count = mysqli_num_rows($result);
  if($count==1){
    $_SESSION['username']=$username;
     header("location: admin_dashbord.php");
     
  }else{
     echo "Invalid Username/password";
  }
}
if(isset($_SESSION['username'])){
  header("location:admin_dashbord.php");
}
?>
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>Admin Login</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

</head>

<body>
  <?php include'home_header.php' ?>
<br><br><br><br><br>

  <center>
    <h1>Admin Login</h1>
    <img src="img/logo/admin-login.png" class="img-responsive">
  <form method="post"><br>
   <input type="text" name="username" placeholder="Enter Username" style="width: 300px; height: 35px;"  required="yes"><br><br>
   <input type="password" name="password" placeholder="Password" style="width: 300px; height: 35px;" required="yes"><br><br>
   <input type="submit" class="btn btn-primary" name="submit"  value="Login" style="width: 100px;">
   <input type="reset" name="reset" value="Clear" class="btn btn-danger" style="width: 100px;"" >
 </form>
 
</div>

<br><br><br><br><br>
<br><br><br><br><br>

  <?php include'footer.php' ?>

  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/jquery.nicescroll.min.js"></script>
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/stellar.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>

</html>
