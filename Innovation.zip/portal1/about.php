
<!DOCTYPE html>
<html>

<head>
  <!-- BASICS -->
  <meta charset="utf-8">
  <title>Admin Login</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo/favicon.svg" />
  <link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen">
  <link rel="stylesheet" type="text/css" href="css/isotope.css" media="screen">
  <link rel="stylesheet" href="css/flexslider.css" type="text/css">
  <link rel="stylesheet" href="js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif:400,400italic,700|Open+Sans:300,400,600,700">
  <link rel="stylesheet" href="css/style.css">
  <!-- skin -->
  <link rel="stylesheet" href="skin/default.css">
  <!-- =======================================================
    Theme Name: Vlava
    Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

</head>

<body>
  <?php include'home_header.php' ?>
<br><br><br><br><br>

  <center>
  <h1>About Us</h1>
    <div class="container">
   We have to design and develop a portal which is accessible by all institute and colleges. The Innovative ideas will be uploaded by students and admin also. An Innovation employee from National Innovation Council can play a role of admin. When admin or student will submit any innovative idea on that portal then all students will be see and if they can implement it then they will send a mail to admin that we have start working on that idea. A project report will be sent to admin after completion of the project. After that the admin will see the working of the project what they implement. If the project quality will be fine then admin will accept that and he give the price money to the student who implement it and if National Innovation Council needs any projects similar to that project then they will propose to work with them to that student.
Our Mission is devlopment of state rajasthan.this portal is bassed on innovation nad devlopment of
 india.
 The Innovation Portal is a one-stop resource for rajasthan goverment.This portal enables student to sharing and getting innovative ideas for projects.this system provide business friendly descriptions of the technology,new project ideas, smart india devlopment or the patent itself. When you find a technology you are interested in, simply fill out the contact form to get directly.


</div>
<br><br><br><br><br>
<br><br><br><br><br>

  

  <!-- Javascript Library Files -->
  <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
  <script src="js/jquery.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/jquery.nicescroll.min.js"></script>
  <script src="js/fancybox/jquery.fancybox.pack.js"></script>
  <script src="js/skrollr.min.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.localScroll.min.js"></script>
  <script src="js/stellar.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/jquery.flexslider-min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
 
  <script src="js/main.js"></script>
<?php include'footer.php' ?>
</body>

</html>
